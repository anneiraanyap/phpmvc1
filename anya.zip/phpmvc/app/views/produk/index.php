<div class="container mt-3">

<div class="row">
  <div class="col-lg-6">
    <?php flasher::flash();?>
  </div>
</div>

<div class="row mb-3">
  <div class="col-lg-6">
  <button type="button" class="btn btn-secondary tombolTambahData" data-bs-toggle="modal" data-bs-target="#formModal">
    tambah produk jualan
  </button>
  </div>
</div>

<div class="row mb-3">
  <div class="col-lg-6">
  <form action="<?= BASEURL;?>/produk/cari" method="post">
  <div class="input-group">
  <input type="text" class="form-control" placeholder="cari produk.." name="keyword" id="keyword" autocomplete="off">
  <button class="btn btn-secondary" type="submit" id="tombolcari">cari</button>
</div>
</form>
  </div>
</div>

<div class="row">
        <div class="col-lg-4">
        
        <br><br>
            <h3>Daftar Produk</h3>
                    <ul class="list-group">
                    <?php foreach( $data['plj'] as $plj ) : ?>
                      <li class="list-group-item">
                          <?= $plj['nama_produk']; ?>
                          <a href="<?= BASEURL; ?>/produk/hapus/<?= $plj['id']; ?>" class="badge bg-danger float-end me-1" onclick="return confirm('yakin?');">hapus</a>
                          <a href="<?= BASEURL; ?>/produk/ubah/<?= $plj['id']; ?>" class="badge bg-warning float-end me-1 tampilModalUbah" data-bs-toggle="modal" data-bs-target="#formModal" data-id="<?= $plj['id']; ?>">ubah</a>
                          <a href="<?= BASEURL; ?>/produk/detail/<?= $plj['id']; ?>" class="badge bg-primary float-end me-1">detail</a>
                        </li>
                      <?php endforeach; ?>
                    </ul>
                
        </div>
    </div> 

</div>
</div>

</div>  


      <div class="container">
        <div class="row text-center mb-3">
          <div class="col">
          </div>
        </div>
<div class="row">
          <div class="col-md-3 mb-3">
            <div class="card" style="width: 14rem;">
              <img src="img/aya1.jpg" class="card-img-top" alt="aya1" />
              <div class="card-body">
                <p class="card-text">Tulips are a classic flower. Ideal to give someone who you have a deep, unconditional love, like a partner, children, parents or siblings.</p>
              <br><p>Rp.100.000-300.000</p>
              </div>
            </div>
          </div>
          <div class="col-md-3 mb-">
            <div class="card" style="width: 14rem;">
              <img src="img/aya2.jpg" class="card-img-top" alt="aya2" />
              <div class="card-body">
                <p class="card-text">Rose many types of flowers that mean love, but the most iconic is the red rose. The red rose is known as the flower of love</p>
              <br><p>Rp.50.000-150.00</p>
              </div>
            </div>
          </div>
          <div class="col-md-4 mb-">
            <div class="card" style="width: 14rem;">
              <img src="img/aya3.jpg" class="card-img-top" alt="aya3" />
              <div class="card-body">
                <p class="card-text">Baby's breath is blooming with symbolism. Most commonly, this flower is a symbol of everlasting love. Is one reason why it's a popular wedding flower.</p>
              <br><p>Rp.300.000-450.000</p>
              </div>
            </div>
          </div>
          <div class="col-md-3 mb-">
            <div class="card" style="width: 14rem;">
              <img src="img/aya4.jpg" class="card-img-top" alt="aya4" />
              <div class="card-body">
                <p class="card-text">Lilies have associated with love, devotion, purity and fertility. Sweet and innocent beauty of the flower has ensured it remains tied to the ideas of fresh new life.</p>
              <br><p>Rp.100.000-300.00</p>
              </div>
            </div>
          </div>
          <div class="col-md-3 mb-">
            <div class="card" style="width: 14rem;">
              <img src="img/aya5.jpg" class="card-img-top" alt="aya5" />
              <div class="card-body">
                <p class="card-text">The hydrangea represents gratitude, grace and beauty. It also radiates abundance because of the lavish number of flowers and the generous round shape.</p>
              <br><p>Rp.200.000-400.00</p>
              </div>
            </div>
          </div>
          <div class="col-md-3 mb-">
            <div class="card" style="width: 14rem;">
              <img src="img/aya6.jpg" class="card-img-top" alt="aya6" />
              <div class="card-body">
                <p class="card-text">Sunflowers symbolize unwavering faith and unconditional love. It's perfect to send to your loved one if you want to express exactly how much you adore him or her. </p>
              <br><p>Rp.200.000-350.000</p>
              </div>
            </div>
          </div>



<!-- Modal -->
<div class="modal fade" id="formModal" tabindex="-1" aria-labelledby="formModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="formModalLabel">Tambah produk jualan</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">

        <form action="<?= BASEURL; ?>/produk/tambah" method="post">
         <input type="hidden" name="id" id="id"> 
             <div class="form-group">
                 <label for="nama produk">nama produk</label>
                 <input type="text" class="form-control" id="nama produk" name="nama produk" />
              </div>

          <div class="form-group">
            <label for="nrp">kode produk</label>
            <input type="number" class="form-control" id="kode produk" name="kode produk" />
          </div>


          <div class="form-group">
            <label for="harga">harga</label>
            <input type="varchar" class="form-control" id="harga" name="harga" />
          </div>

          <div class="form-group">
               <label for="jenis produk">jenis produk</label>
                 <select class="form-control" id="jenis produk" name="jenis produk">
                     <option value="satuan">satuan</option>
                 <option value="hand bouquet">hand bouquet</option>  
               <option value="flower box">flower box</option>
              <option value="table flower">table flower</option>
                   
            </select>
              </div>




      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Tambah Data</button>
        </form>
      </div>
    </div>
  </div>
    </div>