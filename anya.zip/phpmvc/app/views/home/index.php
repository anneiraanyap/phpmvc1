<div class="container">
    <h1 class="mt-3"></h1>
    <img src="<?=BASEURL; ?>/img/aya.jpg" alt="aya" width="200" class="rounded-circle">
    <p></p>

</div>

<div class="container">
<div class="jumbotron mt-4">
  <h1 class="display-4">welcome to rose des neiges ! 💐</h1>
  <p class="lead"> <?= $data['nama']; ?></p>
  <hr class="my-4">
  <p>💌 - express your feelings by ordering flowers in our shop !</p>
  <a class="btn btn-secondary btn-lg" href="#" role="button">order here</a>
</div>


</div>
